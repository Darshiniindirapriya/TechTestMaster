package com.db.dataplatform.techtest;

import org.junit.Test;

public class TechTestApplicationTest {
    @Test
    public void testInitiatePushDataFlow() {

    }
}
