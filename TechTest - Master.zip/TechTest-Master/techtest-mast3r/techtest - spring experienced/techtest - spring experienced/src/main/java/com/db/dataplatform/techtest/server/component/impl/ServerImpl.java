package com.db.dataplatform.techtest.server.component.impl;

import com.db.dataplatform.techtest.server.api.model.DataBody;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.api.model.DataHeader;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.service.DataBodyService;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.service.DataHeaderService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
// No changes required for this code block.
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.xml.bind.DatatypeConverter;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ServerImpl implements Server {

    private final DataBodyService dataBodyServiceImpl;
    private final DataHeaderService dataHeaderServiceImpl;

    private final ModelMapper modelMapper;
    private final RestTemplate serverRestTemplate;


    public static final String URI_HADOOP_SERVER = "http://localhost:8090/hadoopserver/pushbigdata";


    /**
     * @param envelope
     * @return true if there is a match with the client provided checksum.
     */
    @Override
    public boolean saveDataEnvelope(DataEnvelope envelope) {
        // Save to persistence.
        try {
            log.info("Calculating MD5 checksum of the body of an incoming data block");
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(envelope.getDataBody().getDataBody().getBytes());
            byte[] digest = md.digest();
            envelope.getDataBody().setDataBody(DatatypeConverter.printHexBinary(digest));

            persist(envelope);
            log.info("Data persisted successfully, data name: {}", envelope.getDataHeader().getName());
            publishDataToHadoop(envelope);
            return true;
        } catch (NoSuchAlgorithmException NAE) {
            log.info("Calculating MD5 checksum of the body of an incoming data block failed.");
        } catch (JsonProcessingException j) {
            log.info("Json parsing exception while converting envelop data to string.");
        } catch (Exception e) {
            log.info("Pushing data {} to Hadoop failed with exception {}.", e.getMessage());
        }
        return false;
    }

    @Override
    public List<DataEnvelope> getDataEnvelopeByBlockType(BlockTypeEnum blockType) throws IOException, NoSuchAlgorithmException {
        return getDataByBlockType(blockType);
    }

    @Override
    public Boolean updateDataEvelope(String name, BlockTypeEnum blockType) throws IOException, NoSuchAlgorithmException {
        dataHeaderServiceImpl.updateBlocktype(name, blockType);
        return true;
    }

    private List<DataEnvelope> getDataByBlockType(BlockTypeEnum blockType) throws IOException, NoSuchAlgorithmException {
        List<DataEnvelope> response = new ArrayList<>();
        log.info("Retrieving data for block type {} started.", blockType);
        List<DataBodyEntity> blockTypeData = dataBodyServiceImpl.getDataByBlockType(blockType);
        log.info("Retrieving data for block type {} completed.", blockType);

        blockTypeData.forEach(dataEntity -> {
            DataHeader dataHeader = modelMapper.map(dataEntity.getDataHeaderEntity(), DataHeader.class);
            DataBody dataBody = modelMapper.map(dataEntity, DataBody.class);
            response.add(new DataEnvelope(dataHeader, dataBody));
        });

        return response;
    }

    private void persist(DataEnvelope envelope) throws NoSuchAlgorithmException {
        log.info("Persisting data with attribute name: {}", envelope.getDataHeader().getName());
        DataHeaderEntity dataHeaderEntity = modelMapper.map(envelope.getDataHeader(), DataHeaderEntity.class);

        DataBodyEntity dataBodyEntity = modelMapper.map(envelope.getDataBody(), DataBodyEntity.class);

        dataBodyEntity.setDataHeaderEntity(dataHeaderEntity);
        saveData(dataBodyEntity);

    }

    private void saveData(DataBodyEntity dataBodyEntity) {
        dataBodyServiceImpl.saveDataBody(dataBodyEntity);
    }

    private void publishDataToHadoop(DataEnvelope dataEnvelope) throws JsonProcessingException {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

        String requestBody = new ObjectMapper().writeValueAsString(dataEnvelope);
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<HttpStatus> response = serverRestTemplate.exchange(URI_HADOOP_SERVER, HttpMethod.POST, entity, HttpStatus.class);
        if (response.getStatusCode().value() == 200) {
            log.info("Pushing data {} to Hadoop completed.", dataEnvelope.getDataHeader().getName());
        } else {
            log.info("Pushing data {} to Hadoop failed.", dataEnvelope.getDataHeader().getName());
        }
    }

}
