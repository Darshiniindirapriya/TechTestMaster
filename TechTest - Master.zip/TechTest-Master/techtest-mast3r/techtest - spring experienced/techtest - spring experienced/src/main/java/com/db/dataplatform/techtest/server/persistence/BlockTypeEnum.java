package com.db.dataplatform.techtest.server.persistence;

import java.util.EnumSet;

public enum BlockTypeEnum {
    BLOCKTYPEA("blocktypea"),
    BLOCKTYPEB("blocktypeb");

    BlockTypeEnum(String type) {
        // Remove the unused field 'type'
    }

    public static BlockTypeEnum getByValue(String value){
        for (final BlockTypeEnum element : EnumSet.allOf(BlockTypeEnum.class)) {
            if (element.toString().equals(value)) {
                return element;
            }
        }
        return null;
    }

}
