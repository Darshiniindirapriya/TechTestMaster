package com.db.dataplatform.techtest.client.component.impl;

import com.db.dataplatform.techtest.client.api.model.DataEnvelope;
// import com.db.dataplatform.techtest.client.api.model.DataHeader;
import com.db.dataplatform.techtest.client.component.Client;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Client code does not require any test coverage
 */

@Service
@Slf4j
@RequiredArgsConstructor
public class ClientImpl implements Client {

    private final RestTemplate clientRestTemplate;

    public static final String URI_PUSHDATA = "http://localhost:8090/dataserver/pushdata";
    public static final UriTemplate URI_GETDATA = new UriTemplate("http://localhost:8090/dataserver/data/{blockType}");
    public static final UriTemplate URI_PATCHDATA = new UriTemplate("http://localhost:8090/dataserver/update/{name}/{newBlockType}");

    @Override
    public void pushData(DataEnvelope dataEnvelope) {
        log.info("Pushing data {} to {}", dataEnvelope.getDataHeader().getName(), URI_PUSHDATA);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<DataEnvelope> entity = new HttpEntity<>(dataEnvelope, headers);
        ResponseEntity<Boolean> response = clientRestTemplate.exchange(URI_PUSHDATA, HttpMethod.POST, entity, Boolean.class);
        if (response.getBody()) {
            log.info("Pushing data {} to {} completed.", dataEnvelope.getDataHeader().getName(), URI_PUSHDATA);
        } else {
            log.info("Pushing data {} to {} failed.", dataEnvelope.getDataHeader().getName(), URI_PUSHDATA);
        }
    }

    @Override
    public List<DataEnvelope> getData(String blockType) {
        log.info("Query for data with header block type {}", blockType);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<String>(headers);

        Map<String, String> uriVariables = new HashMap<>();
        uriVariables.put("blockType", blockType);

        ResponseEntity<List<DataEnvelope>> response = clientRestTemplate.exchange(
            URI_GETDATA.expand(uriVariables).toString(), HttpMethod.GET, entity, new ParameterizedTypeReference<List<DataEnvelope>>() {
            });
        return response.getBody();
    }

    @Override
    public boolean updateData(String blockName, String newBlockType) {
        log.info("Updating blocktype to {} for block with name {}", newBlockType, blockName);

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<String>(headers);

        Map<String, String> uriVariables = new HashMap<>();
        uriVariables.put("name", blockName);
        uriVariables.put("newBlockType", newBlockType);

        ResponseEntity<Boolean> response = clientRestTemplate.exchange(
                URI_PATCHDATA.expand(uriVariables).toString(), HttpMethod.PATCH, entity, Boolean.class);


        if (response.getBody()) {
            log.info("Updating blocktype to {} for block with name {} completed", newBlockType, blockName);
            return true;
        } else {
            log.info("Updating blocktype to {} for block with name {} failed", newBlockType, blockName);
        }
        return false;
    }


}
